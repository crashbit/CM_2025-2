//
//  ViewController.swift
//  Proy_CM_01
//
//  Created by Germán Santos Jaimes on 19/02/25.
//

import UIKit

class ViewController: UIViewController {
    let nombre:String = "Algún alumno 🥸"
    
    var numero: Int = 0
    
    @IBOutlet weak var letrero: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        letrero.text = "0"
    }

    @IBAction func sumar(_ sender: UIButton) {
        if numero > 9{
            numero = 10
            sender.tintColor = .red
        }else{
            numero = numero + 1
        }
        
        letrero.text = String(numero)
    }
    
}

