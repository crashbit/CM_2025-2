//
//  ViewController.swift
//  Proy_CM_02
//
//  Created by Germán Santos Jaimes on 24/02/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var letrero: UILabel!
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var slider1: UISlider!
    @IBOutlet weak var slider2: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        letrero.text = "0"
        view.backgroundColor = .red
    }

    
    @IBAction func sliderChange(_ sender: UISlider) {
        print(slider.value, slider1.value, slider2.value)
        var rojo: CGFloat = CGFloat(slider.value)
        var verde: CGFloat = CGFloat(slider1.value)
        var azul: CGFloat = CGFloat(slider2.value)
        
        if sender.tag == 0{
            print("Slider cero se movio")
        }else if sender.tag == 1{
            print("Slider 1 se movio")
        }else{
            print("Slider 2 se movio")
        }
            
        letrero.text = String(Int(slider.value))
        
        view.backgroundColor = UIColor(red: rojo, green: verde, blue: azul, alpha: CGFloat(0.5))
       
        
    }
    
}

